import matplotlib.pyplot as plt
import matplotlib

font = {'size'   : 11}

matplotlib.rc('font', **font)


f= open("sleep_8kb.log","r")
text = f.read()
# print text
tests = text.split('end')
# print tests
tests =filter(lambda z : len(z)!=0, map(lambda x: filter(lambda y: len(y)!=0, x.split('\n')), tests))
print tests

colors = ["red", "blue", "green", "orange"]
co = 0

f = plt.figure(figsize=(6.5,3))

def plot_graph(input_list):	
	global co
	global f
	title = input_list[0]
	runs = int(input_list[1].split(' ')[1])
	print title, runs
	data = input_list[2:]
	data = map(lambda x: int(x.split(' ')[0]), data)
	data = map(lambda x: x-750, data)
	plt.plot(data,"ob-",label=title, color= colors[co])
	print data
	co+=1

for x in tests:
	plot_graph(x)

# fig = plt.figure(figsize=(9, 11))
# ax = plt.subplot(111)

# plt.title('Write System Call Overhead')
plt.ylim(bottom=2750 ,top=3050)
plt.gca().yaxis.grid(True)
plt.xlabel("Run Number")
plt.ylabel("Time per syscall (ns/op)")
plt.legend(loc='upper right')
plt.savefig('sleep_8kb.pdf', bbox_inches='tight',dpi = 500) 
# plt.show()
