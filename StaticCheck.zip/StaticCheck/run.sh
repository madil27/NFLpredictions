# LKMDIR=/home/adil/write_syscall_hook
# PATH_CONFIG=/home/adil/write_syscall_hook/scripts/target_config_file.txt
# WRITES_SEC=5 

LKMDIR=$2
PATH_CONFIG=$3
PATH_RANDOM=$4
WRITES_SEC=$5
RANGE=$1


if [[ -z "$4" ]]; then
	echo "Error: Specify all required arguments"
	echo "source run.sh [NUM_SCRIPTS] [LKM_DIR] [PATH_CONFIG] [PATH_RANDOM] [WRITES_PER_SEC]"
fi

source static_check.sh -clean $RANGE $LKMDIR $PATH_CONFIG $PATH_RANDOM $WRITES_SEC 

source static_check.sh -reg $RANGE $LKMDIR $PATH_CONFIG $PATH_RANDOM $WRITES_SEC
sleep 2m
source static_check.sh -test $RANGE $LKMDIR $PATH_CONFIG $PATH_RANDOM $WRITES_SEC
sleep 2m
source static_check.sh -lkm $RANGE $LKMDIR $PATH_CONFIG $PATH_RANDOM $WRITES_SEC
sleep 2m
source static_check.sh -run $RANGE $LKMDIR $PATH_CONFIG $PATH_RANDOM $WRITES_SEC

python plot_static.py
# source static_check.sh -clean $RANGE $LKMDIR $PATH_CONFIG $WRITES_SEC 
# source static_check.sh -reg $RANGE 
# source static_check.sh -reg $RANGE 

