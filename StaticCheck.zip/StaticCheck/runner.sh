PERCENT=$1

for (( i = 0; i < 10; i++ )); do
	echo "start run $i"
	python3 write.py $PERCENT >> adil.log &
done
