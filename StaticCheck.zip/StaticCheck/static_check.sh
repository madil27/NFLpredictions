# LKMDIR=/path/to/write_syscall_hook
# WORKDIR=/path/to/current_dir
# LKMDIR=/home/adil/write_syscall_hook
# WORKDIR=/home/adil/Desktop/provconf/code/benchmark/StaticCheck

LKM=$1
RANGE=$2
LKMDIR=$3
PATH_CONFIG=$4
PATH_RANDOM=$5
WRITES_SEC=$6


WORKDIR=$(pwd)
if [[ -z "$2" ]]; then
	RANGE=10
	
fi

#killing any old processes if any
ps -ef | grep 'python write.py' | grep -v grep | awk '{print $2}' | xargs -r kill -9
ps -ef | grep 'python write.py' | grep -v grep | awk '{print $2}' | xargs -r kill -9


if [[ $LKM =~ "lkm" ]]; then
	cd $LKMDIR
	make && sudo sh ./load.sh 
	cd $WORKDIR
	echo "Kernel-Module:1, Config Writes:0" >> final.log
	echo "runs: $RANGE" >> final.log
	gcc write_sys.c -o write_sys
	for (( i = 0; i < RANGE; i++ )); do
		echo "write in non-config"
		python write.py $PATH_RANDOM $WRITES_SEC &
	done

	for (( i = 0; i < RANGE; i++ )); do
		echo "start run $i"
		./write_sys $i >> final.log &
		pids="$pids $!"
	done
	wait $pids
	echo "end" >> final.log
	ps -ef | grep 'python write.py' | grep -v grep | awk '{print $2}' | xargs -r kill -9
	ps -ef | grep 'python write.py' | grep -v grep | awk '{print $2}' | xargs -r kill -9


elif [[ $LKM =~ "reg" ]]; then
	echo "Kernel Module:0 , Config Writes:0" >> final.log
	echo "runs: $RANGE" >> final.log
	gcc write_sys.c -o write_sys
	for (( i = 0; i < RANGE; i++ )); do
		echo "write in non-config"
		python write.py $PATH_RANDOM $WRITES_SEC &
	done

	for (( i = 0; i < RANGE; i++ )); do
		echo "start run $i"
		./write_sys $i >> final.log &
		pids="$pids $!"
	done
	wait $pids
	echo "end" >> final.log
	ps -ef | grep 'python write.py' | grep -v grep | awk '{print $2}' | xargs -r kill -9
	ps -ef | grep 'python write.py' | grep -v grep | awk '{print $2}' | xargs -r kill -9
	# ./write_sys >> final.log &
	# ./write_sys >> final.log &


elif [[ $LKM =~ "run" ]]; then
	pids=""
	cd $LKMDIR
	make && sudo sh ./load.sh 
	cd $WORKDIR
	echo "Kernel Module:1 , Config Writes: 1" >> final.log
	echo "runs: $RANGE" >> final.log
	gcc write_sys.c -o write_sys
	for (( i = 0; i < RANGE; i++ )); do
		echo "write in config"
		python write.py $PATH_CONFIG $WRITES_SEC &
	done

	for (( i = 0; i < RANGE; i++ )); do
		echo "start run $i"
		./write_sys $i >> final.log &
		pids="$pids $!"
	done
	wait $pids
	echo "end" >> final.log
	ps -ef | grep 'python write.py' | grep -v grep | awk '{print $2}' | xargs -r kill -9
	ps -ef | grep 'python write.py' | grep -v grep | awk '{print $2}' | xargs -r kill -9

elif [[ $LKM =~ "clean" ]]; then
	cd $LKMDIR
	make clean
	sudo rmmod lkh 
	cd $WORKDIR
	rm final.log
	echo "" > $PATH_CONFIG
	echo "" > $PATH_RANDOM

elif [[ $LKM =~ "test" ]]; then
	pids=""
	echo "Kernel Module: 0 , Config Writes: 1" >> final.log
	echo "runs: $RANGE" >> final.log
	gcc write_sys.c -o write_sys
	for (( i = 0; i < RANGE; i++ )); do
		echo "write in config"
		python write.py $PATH_CONFIG $WRITES_SEC &
	done

	for (( i = 0; i < RANGE; i++ )); do
		echo "start run $i"
		./write_sys $i >> final.log &
		pids="$pids $!"
	done

	wait $pids
	echo "end" >> final.log
	ps -ef | grep 'python write.py' | grep -v grep | awk '{print $2}' | xargs -r kill -9
	ps -ef | grep 'python write.py' | grep -v grep | awk '{print $2}' | xargs -r kill -9

	# ./write_sys >> final.log &
	# ./write_sys >> final.log &
else
	echo "Usage: source static_check.sh [OPTION]"
	echo ""
	echo "	-lkm, run with kernel module and NO config file writes"
	echo "	-run, run with kernel module and config file writes"
	echo "	-reg, run without kernel module and NO config file writes"
	echo "	-test, run without kernel module andconfig file writes"
	
fi