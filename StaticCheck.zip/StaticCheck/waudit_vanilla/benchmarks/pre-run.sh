#!/bin/bash
sudo apt update -y

sudo apt install -y apache2
sudo apt install -y apache2-utils

sudo apt install -y nginx