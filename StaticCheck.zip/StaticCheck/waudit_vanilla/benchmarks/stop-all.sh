sudo systemctl stop redis.service
sudo systemctl stop apache2.service
sudo systemctl stop nginx
sudo service memcached stop
sudo systemctl stop proftpd
sudo service squid stop
sudo service sshd stop
sudo service transmission-daemon stop
