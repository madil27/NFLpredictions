sudo service sshd start
sudo service sshd reload
sudo service ssh start
sudo service rsyslog restart
sudo bash ~/projects/waudit/start-audit.sh 1
sleep 2
starttime=`date +%s.%N`
for i in $(seq 1 2)
do
    sshpass -p 'wlog'  ssh myproftpduser@127.0.0.1 "pwd"
    sshpass -p 'wlog'  ssh myproftpduser@127.0.0.1 "ls /"
    wait
done
sudo service sshd stop

sudo bash ~/projects/waudit/stop-audit.sh
