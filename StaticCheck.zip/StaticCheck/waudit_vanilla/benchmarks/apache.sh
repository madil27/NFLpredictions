#!/bin/bash
sudo systemctl stop apache2.service
sudo systemctl start apache2.service
ab -n 10 -c 1 http://localhost:80/
sudo systemctl stop apache2.service