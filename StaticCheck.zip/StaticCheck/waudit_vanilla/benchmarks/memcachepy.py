from pymemcache.client import base
client = base.Client(('localhost', 11211))

for i in range(50):
 client.set(format(i*5), format(i))
 print(client.get(format(i*5)))
 print("\n")
