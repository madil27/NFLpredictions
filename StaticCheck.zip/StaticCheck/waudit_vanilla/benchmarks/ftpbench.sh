#!/bin/bash

sudo service proftpd restart
ftpbench -h 127.0.0.1 -u myproftpduser -p wlog --concurrent=5 login
ftpbench -h 127.0.0.1 -u myproftpduser -p wlog --size=1 --files=5 --concurrent=5  download /tmp/
sudo service proftpd stop