#!/bin/bash



sudo systemctl restart nginx
ab -n 12 -c 1 http://localhost:80/
sudo systemctl stop nginx