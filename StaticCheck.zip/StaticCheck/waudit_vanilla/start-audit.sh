#!/bin/bash
if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Complete arguments not provided." 
    echo "Need first argument for wlog. 1 means start app logging and 0 means no app logging"
    echo "Need Second Argument for the complete path to the configuration file"
    exit 1
fi
FILE="original.conf"
sudo service auditd stop
sudo rm /var/log/audit/audit.log*
sudo cp $2 temp/$FILE # Copy into temp folder
sudo chmod a+rwx temp/$FILE # Change permissions
sudo service auditd start
echo "ADDING KERNEL MODULES ===="
sudo bash addmods.sh "$1" "$2"

sudo bash audit-rules.sh add
sudo bash audit-rules.sh enable
echo "==== Status ===== "
sudo bash audit-rules.sh status
