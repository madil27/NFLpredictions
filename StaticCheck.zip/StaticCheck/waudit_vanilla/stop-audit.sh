#!/bin/bash
FILE="backup$(date "+%s").log"
sudo bash audit-rules.sh remove
sudo bash audit-rules.sh disable
echo "==== Status ====="
sudo bash audit-rules.sh status

echo "REMOVING KERNEL MODULES ===="
sudo bash rmmods.sh

# sudo cp /var/log/audit/audit.log backup/$FILE #Create backup of audit logs
# sudo cp /var/log/audit/audit.log diff-computer/audit.log # put audit.log into diff-computer for refinement
# sudo chmod a+rwx backup/$FILE #Create backup of audit logs
# sudo chmod a+rwx diff-computer/audit.log

# # Compute diffs below
# cp temp/$(ls temp | head -1) diff-computer/original.conf
# python3 temp/parse.py