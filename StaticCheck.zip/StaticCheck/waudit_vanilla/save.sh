if [ -z "$1" ]; then
	echo "Kindly provide name of the log file as an argument" 
fi

sudo cp /var/log/audit/audit.log /home/adil/Desktop/"$1".log