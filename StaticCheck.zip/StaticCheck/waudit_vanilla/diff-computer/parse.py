import difflib
from itertools import groupby
import codecs

original_file = '' # update this later


def get_buf_and_offset(filename):
	global original_file
	f= open(filename, "r")
	content = f.read()
	f.close()
	original_file = content
	content = content.split('\n')
	content = list( dict.fromkeys(content) )
	relevant_data = filter(lambda x : ("data=" in x) and ("offset=") , content)
	content = filter(lambda x : ("data=" in x) and ("offset=" in x) , content)
	content = map( lambda x : (x , x.split("data")[1][1:].strip('\x00').strip('"')), content)
	# content = map( lambda x : x.split("dataTransferred")[1][1:], content)
	content =list( map( lambda x : (x[0], codecs.decode(x[1],"hex").decode('ascii')), content)) # Decode hex values
	# print("content:",content)
	for x in content: print(x)
	content = list(map(lambda x:(x[0], x[1], int((x[0].split("offset="))[1].split(" data=")[0], 16)) , content)) # offsets extraction
	content = list(map(lambda x:( x[0],x[1],x[2],int((x[0].split("msg=audit("))[1].split(":")[0].split(".")[0])) , content)) # time stamp extraction

	# content = [(original audit entry, string buffer, offset, timestamp )]
	print("timestamp:",list(map(lambda x: x[3],content)))
	# print(timestamp)
	# fin = zip(content, offset)
	mark_index = []
	init_index = []

	clusters = {}
	for x in content:
		if x[3] in clusters:
			clusters[x[3]].append(x)
		else:
			clusters[x[3]] = [x]
	return clusters

def make_new(clusters, filename):
	global counter
	global original_file
	f= open(filename, "r")
	content = f.read()
	f.close()
	sorted_clusters = []
	for x in sorted(clusters.keys()):
		sorted_clusters.append(clusters[x])

	initial_version = content
	new_log_entries = []
	#traverse sorted clusters
	for list_content in sorted_clusters:
		if len(list_content) < 1:
			continue
		print(len(list_content))
		current_string = initial_version
		for x in list_content:
			# (original entry, buffer, offset, timestamp)
			# print ("Simulating Write Syscall!")
			offset = x[2]
			# print("Offset: ", offset)
			buffer_inp = x[1]
			initial_string = current_string[:offset]
			current_string = initial_string + buffer_inp + current_string[(offset+len(buffer_inp)):]
		# current string is now the file which needs diffs
		# intial version is the previous version
		content_lines = initial_version.split('\n') # prev version
		content_lines = {x:content_lines.count(x) for x in content_lines} # -ve
		current_lines = current_string.split('\n') # new version
		current_lines = {x:current_lines.count(x) for x in current_lines} # +ve

		for line in content_lines.keys():
			if line not in current_lines:
				current_lines[line] = -content_lines[line]
			else:
				current_lines[line] -= content_lines[line]
		current_lines = dict(filter(lambda elem: elem[1] is not 0, current_lines.items()))
		list_positive = [x for x in current_lines.items() if x[1] > 0] # lines added
		list_negative = [x for x in current_lines.items() if x[1] < 0] # lines removed

		print( "DIFFS COMPONENT DIFFLIB")
		final_string = "Lines Added:\n"

		for x in list_positive:
			for y in range(x[1]):
				final_string += (x[0]+"\n")
		final_string += "------------\n"
		final_string += "Lines Removed:\n"
		for x in list_negative:
			for y in range(x[1]):
				final_string += (x[0]+ "\n")
		final_string += "-------------\n"

		print(final_string)
		final_string = final_string.encode("utf-8").hex() # convert to hex
		# print(final_string)

		audit_entry_original = list_content[0][0] # take the first element from list of audit entries
		# print("audit:",audit_entry_original)
		token = "data="
		new_entry = audit_entry_original[:audit_entry_original.index(token)+ len(token)]
		new_entry += (final_string + '"')
		new_log_entries.append(new_entry) # Created new entry for audit log here!!!!
		# update initial version to new created version
		initial_version = current_string

	list_of_original_target_entries = list(map(lambda x: x[0],sum( [x[1] for x in clusters.items()] , [])))
	copy_original = original_file
	copy_original = copy_original.split('\n')
	copy_original = list( dict.fromkeys(copy_original) )
	copy_original = list(filter(lambda x : x not in list_of_original_target_entries , copy_original))
	copy_original = copy_original + new_log_entries
	return copy_original

# def make_new(list_inp):
# 	global counter
# 	f= open('/home/adil/write_syscall_hook/scripts/target_config_initial.txt', "r")
# 	content = f.read()
# 	f.close()
# 	# print "original file:\n{}".format(content)
# 	for x in list_inp:
# 		print ("Simulating Write Syscall!")
# 		lines_to_remove = set()
# 		offset = x[1]
# 		print("Offset: ", offset)
# 		buffer_inp = x[0]
# 		find_diff = x[2]
# 		initial_string = content[:offset]
# 		current_string = initial_string + buffer_inp + content[(offset+len(buffer_inp)):]
		
# 		# print "newfile:\n{}".format(current_string)
# 		print(" --- FILE DIFFS --- ")
# 		content_lines = content.split('\n')
# 		current_lines = current_string.split('\n')
# 		for line in content_lines:
# 			lines_to_remove.add(line.strip())
# 		for line in current_lines:
# 			if line.strip() not in lines_to_remove:
# 				# counter += 1
# 				print(line.strip())
# 			# content = current_string

# 		# print "DIFFS COMPONENT DIFFLIB"
# 		# for line in difflib.unified_diff(content, current_string, fromfile='init', tofile='new'):
# 		# 	print line,

# 		content = current_string
# 	return content

counter = 0	
path = 'audit.log'
original_file_name = 'original.conf'
clusters = get_buf_and_offset(path)
# content = [(original audit entry, string buffer, offset, timestamp )]

# print("final:",  dict(map(lambda x: (x[0],list(map(lambda z: ("log","buffer",z[2],z[3]) ,x[1])) ), clusters.items() )))
# file = read_config()
# print "Actual file size:", len(file)
# ans = map(lambda x : (len(x[0]),x[1],file.find(x[0].strip('\x00'))),clusters)
# for x in ans:
# 	print "sizeof buff:",x[0],"file offset:",x[1],"findvalindex:",x[2]
print("reconstruction of file!!!")
recons_file = make_new(clusters, original_file_name)
f = open("new_audit.log", "w")
final_text= "\n".join(recons_file)
final_text += "\n"
f.write(final_text)
f.close()