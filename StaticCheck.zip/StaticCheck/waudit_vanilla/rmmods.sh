rmmod ./kernel-modules/netio_controller.ko
rmmod ./kernel-modules/netio.ko
