* PRE REQS * 

Clone the Linux Kernel Module (https://github.com/aliahad97/write_syscall_hook). 
Make sure you have updated the "path_to_config_file" variable in the file "write_syscall_hook/hooks.c" to the complete path 
of your test config file. 



Then run, 

`source run.sh [NUM_SCRIPTS] [LKM_DIR] [PATH_CONFIG] [PATH_RANDOM] [WRITES_PER_SEC]`

NUM_SCRIPTS = Number of Concurrent Scripts

LKM_DIR = Path to write_syscall_hook directory. write_syscall_hook is the kernel module for logging config files. https://github.com/aliahad97/write_syscall_hook 

PATH_CONFIG = path to the config file. Should be the same as hardcoded in the Linux Kernel Module.

PATH_RANDOM = path to the a random non-config file. (Preferably in the same dir as the config file)

WRITES_PER_SEC = Number of random writes per second per script in the test runs

